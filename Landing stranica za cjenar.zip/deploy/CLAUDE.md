# Cjenar — upute za Claude Code

Statička web aplikacija za obradu i objavu cjenika (HR, EUR, sidrene cijene, HOK XML).

## Datoteke
- `index.html` — landing stranica (samostalna, bez vanjskih ovisnosti osim Google Fonts).
- `app.html` — aplikacija: prijava (e-mail + lozinka), administrator, stavke, uvoz (HOK XML, Excel 2003 XML, CSV, XLSX), objava XML/CSV, dizajn i ispis PDF-a (A4/A5/A6/DL/kvadrat, 3 predloška), arhiva i sigurnosne kopije.
- Obje datoteke su kompilirane (inline bundle) — **ne uređivati ručno**. Izvor se uređuje u Claude dizajn projektu i ponovno izvozi.

## Objava (GitHub Pages)
1. Datoteke iz ove mape stavite u korijen repozitorija `uredwoki-svg/cjenar` (grana `main`).
2. Settings → Pages → Source: *Deploy from a branch* → `main` / `/ (root)`.
3. Poveznica: `https://uredwoki-svg.github.io/cjenar/` (landing) i `.../app.html` (aplikacija).
4. Prvo otvaranje `app.html` traži postavljanje administratora (e-mail + lozinka).

## Važno ograničenje (trenutno stanje)
Podaci (korisnici, cjenici, arhiva) spremaju se u `localStorage` preglednika. Lozinke su PBKDF2-SHA256 (150 000 iteracija) sažeci.
Svaki preglednik/uređaj ima zasebne podatke. Prijenos: Korisnici → *Izvezi sve* / *Uvezi sve* (JSON).

## Sljedeći korak — poslužitelj (Supabase)
Zamijeniti localStorage sloj u `app.html` izvoru:
- `getAcc/putAcc`, `hashPw`, `doLogin/doSetup` → Supabase Auth (email+password), tablica `profiles(id, email, role, naziv, disabled)`.
- `dataKey(email)` → tablica `cjenici(user_id, data jsonb, updated_at)` s RLS (`user_id = auth.uid()`; admin vidi sve).
- `arhiva` → tablica `objave(user_id, broj, generated, snap jsonb)`; `uvozi` → Supabase Storage bucket `uvozi/`.
- `bkKey` → tablica `kopije(user_id, at, reason, data jsonb)`.
- Admin „Dodaj korisnika” → Edge Function s `service_role` ključem (`auth.admin.createUser`), nikad ključ u pregledniku.
