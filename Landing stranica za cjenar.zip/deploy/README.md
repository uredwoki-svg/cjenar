# Cjenar

Obrada i objava cjenika za hrvatske tvrtke i obrte.

- Landing: `index.html`
- Aplikacija: `app.html`

Upute za objavu i razvoj: vidi `CLAUDE.md`.
